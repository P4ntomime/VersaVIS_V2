/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "variant.h"

const PinDescription g_APinDescription[] = {

/*
+--------------+------------+----------+---------+-------------+
|  Pin Number  |  PIN       | VersaVIS | I/O Pin | Attribute   |
| (in program) | (physical) | function |         |             |
+--------------+------------+----------+---------+-------------+
| 00           | 03         | VOUT     | PA02    | Analog In   |
| 01           | 29         | GCLK_IO  | PA20    | Digital In  |
|              |            |          |         |             |
| 02           | 09         | TrigC0   | PA04    | Digital Out |
| 03           | 10         | ExpC0    | PA05    | Digital In  |
|              |            |          |         |             |
| 04           | 11         | TrigC1   | PA06    | Digital Out |
| 05           | 12         | ExpC1    | PA07    | Digital In  |
|              |            |          |         |             |
| 06           | 25         | TrigC2   | PA16    | Digital Out |
| 07           | 26         | ExpC2    | PA17    | Digital In  |
|              |            |          |         |             |
| 08           | 22         | SCK 1    | PA13    | Sercom 2[1] |
| 09           | 23         | MISO 1   | PA14    | Sercom 2[2] |
| 10           | 21         | MOSI 1   | PA12    | Sercom 2[0] |
| 11           | 24         | SS 1     | PA15    | Sercom 2[3] |
| 12           | 27         | ClkOut 1 | PA18    | Digital Out |
| 13           | 28         | DR 1     | PA19    | Digital In  |
|              |            |          |         |             |
| 14           | 14         | SCK 2    | PA09    | Sercom 0[1] |
| 15           | 15         | MISO 2   | PA10    | Sercom 0[2] |
| 16           | 13         | MOSI 2   | PA08    | Sercom 0[0] |
| 17           | 16         | SS 2     | PA11    | Sercom 0[3] |
| 18           | 19         | ClkOut 2 | PB10    | Digital Out |
| 19           | 20         | DR 2     | PB11    | Digital In  |
|              |            |          |         |             |
| 20           | 31         | SDA      | PA22    | Sercom 3[0] |
| 21           | 32         | SCL      | PA23    | Sercom 3[1] |
|              |            |          |         |             |
| 22           | 08         | RX 1     | PB09    | Sercom 4[1] |
| 23           | 07         | TX 1     | PB08    | Sercom 4[0] |
|              |            |          |         |             |
| 24           | 48         | RX 2     | PB03    | Sercom 5[1] |
| 25           | 47         | TX 2     | PB02    | Sercom 5[0] |
|              |            |          |         |             |
| 26           | 39         | PPS_IN   | PA27    | Digital In  |
|              |            |          |         |             |
| 27           | 41         | EVENT_IN | PA28    | Digital In  |
|              |            |          |         |             |
| 28           | 38         | TrigAux0 | PB23    | Digital Out |
| 29           | 37         | DRAux0   | PB22    | Digital In  |
| 30           | 04         | AAux1    | PA03    | Analog In   |
|              |            |          |         |             |
| 31           | 33         | USB-     | PA24    | USB         |
| 32           | 34         | USB+     | PA25    | USB         |
| 33           | 30         | USB_HE   | PA21    | (USB)       |
+--------------+------------+----------+---------+-------------+
*/
  { PORTA,  2, PIO_ANALOG,      (PIN_ATTR_DIGITAL|PIN_ATTR_ANALOG /*DAC*/         ), ADC_Channel0,   NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 20, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT ), No_ADC_Channel, PWM0_CH6,   TCC0_CH6,     EXTERNAL_INT_4    },

  { PORTA,  4, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER                  ), No_ADC_Channel, NOT_ON_PWM, TCC0_CH0,     EXTERNAL_INT_NONE },
  { PORTA,  5, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_5    },

  { PORTA,  6, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER                  ), No_ADC_Channel, NOT_ON_PWM, TCC1_CH0,     EXTERNAL_INT_NONE },
  { PORTA,  7, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7    },

  { PORTA, 16, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER                  ), No_ADC_Channel, NOT_ON_PWM, TCC2_CH0,     EXTERNAL_INT_NONE },
  { PORTA, 17, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_13   },

  { PORTA, 13, PIO_SERCOM,      (PIN_ATTR_NONE                                    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 14, PIO_SERCOM,      (PIN_ATTR_NONE                                    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 12, PIO_SERCOM,      (PIN_ATTR_NONE                                    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 15, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 18, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER                  ), No_ADC_Channel, NOT_ON_PWM, TC3_CH0     , EXTERNAL_INT_NONE },
  { PORTA, 19, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3    },

  { PORTA,  9, PIO_SERCOM,      (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 10, PIO_SERCOM,      (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA,  8, PIO_SERCOM,      (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 11, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTB, 10, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER                  ), No_ADC_Channel, NOT_ON_PWM, TC5_CH0,      EXTERNAL_INT_NONE },
  { PORTB, 11, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_11   },

  { PORTA, 22, PIO_SERCOM,      (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 23, PIO_SERCOM,      (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },

  { PORTB,  9, PIO_SERCOM_ALT,  (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTB,  8, PIO_SERCOM_ALT,  (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },

  { PORTB,  3, PIO_SERCOM_ALT,  (PIN_ATTR_DIGITAL                                 ), ADC_Channel11,  NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTB,  2, PIO_SERCOM_ALT,  (PIN_ATTR_DIGITAL                                 ), ADC_Channel10,  NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },

  { PORTA, 27, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_15   },

  { PORTA, 28, PIO_DIGITAL,     (PIN_ATTR_NONE                                    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_8    },

  { PORTB, 23, PIO_DIGITAL,     (PIN_ATTR_DIGITAL|PIN_ATTR_TIMER                  ), No_ADC_Channel, NOT_ON_PWM, TC7_CH1     , EXTERNAL_INT_NONE },
  { PORTB, 22, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_6    },
  { PORTA,  3, PIO_ANALOG,      (PIN_ATTR_DIGITAL                                 ), ADC_Channel1  , NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  
  { PORTA, 24, PIO_COM,         (PIN_ATTR_NONE                                    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 25, PIO_COM,         (PIN_ATTR_NONE                                    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 21, PIO_DIGITAL,     (PIN_ATTR_DIGITAL                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
};

extern "C" {
    unsigned int PINCOUNT_fn() {
        return (sizeof(g_APinDescription) / sizeof(g_APinDescription[0]));
    }
}

const void* g_apTCInstances[TCC_INST_NUM + TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 };

// Multi-serial objects instantiation
SERCOM sercom0(SERCOM0);
SERCOM sercom1(SERCOM1);
SERCOM sercom2(SERCOM2);
SERCOM sercom3(SERCOM3);
SERCOM sercom4(SERCOM4);
SERCOM sercom5(SERCOM5);

// Serial1
Uart Serial1(&sercom4, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX);
Uart Serial(&sercom5, PIN_SERIAL_RX, PIN_SERIAL_TX, PAD_SERIAL_RX, PAD_SERIAL_TX);

void SERCOM4_Handler()
{
  Serial1.IrqHandler();
}

void SERCOM5_Handler()
{
  Serial.IrqHandler();
}

